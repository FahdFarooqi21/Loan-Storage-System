public interface CheckerPrinter {

    //Method to check eligibility of customer to add more loan records.
    void checkEligibility();

    //Method to print details of loans.
    void printDetails();

}
